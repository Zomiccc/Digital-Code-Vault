
Object.defineProperty(exports, "__esModule", { value: true });

const {
  Decimal,
  objectEnumValues,
  makeStrictEnum,
  Public,
  getRuntime,
  skip
} = require('@prisma/client/runtime/index-browser.js')


const Prisma = {}

exports.Prisma = Prisma
exports.$Enums = {}

/**
 * Prisma Client JS version: 5.22.0
 * Query Engine version: 605197351a3c8bdd595af2d2a9bc3025bca48ea2
 */
Prisma.prismaVersion = {
  client: "5.22.0",
  engine: "605197351a3c8bdd595af2d2a9bc3025bca48ea2"
}

Prisma.PrismaClientKnownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientKnownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)};
Prisma.PrismaClientUnknownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientUnknownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientRustPanicError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientRustPanicError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientInitializationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientInitializationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientValidationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientValidationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.NotFoundError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`NotFoundError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.Decimal = Decimal

/**
 * Re-export of sql-template-tag
 */
Prisma.sql = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`sqltag is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.empty = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`empty is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.join = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`join is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.raw = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`raw is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.validator = Public.validator

/**
* Extensions
*/
Prisma.getExtensionContext = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.getExtensionContext is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.defineExtension = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.defineExtension is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}

/**
 * Shorthand utilities for JSON filtering
 */
Prisma.DbNull = objectEnumValues.instances.DbNull
Prisma.JsonNull = objectEnumValues.instances.JsonNull
Prisma.AnyNull = objectEnumValues.instances.AnyNull

Prisma.NullTypes = {
  DbNull: objectEnumValues.classes.DbNull,
  JsonNull: objectEnumValues.classes.JsonNull,
  AnyNull: objectEnumValues.classes.AnyNull
}



/**
 * Enums
 */

exports.Prisma.TransactionIsolationLevel = makeStrictEnum({
  ReadUncommitted: 'ReadUncommitted',
  ReadCommitted: 'ReadCommitted',
  RepeatableRead: 'RepeatableRead',
  Serializable: 'Serializable'
});

exports.Prisma.AdminUserScalarFieldEnum = {
  id: 'id',
  email: 'email',
  name: 'name',
  passwordHash: 'passwordHash',
  role: 'role',
  twoFactorSecret: 'twoFactorSecret',
  isActive: 'isActive',
  lastLoginAt: 'lastLoginAt',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.MerchantScalarFieldEnum = {
  id: 'id',
  name: 'name',
  email: 'email',
  address: 'address',
  status: 'status',
  walletBalance: 'walletBalance',
  currency: 'currency',
  allowedProductIds: 'allowedProductIds',
  twoFactorRequired: 'twoFactorRequired',
  totalKeysGenerated: 'totalKeysGenerated',
  lastKeyGeneratedAt: 'lastKeyGeneratedAt',
  webhookSecret: 'webhookSecret',
  firstName: 'firstName',
  lastName: 'lastName',
  phone: 'phone',
  idDocType: 'idDocType',
  idFrontImage: 'idFrontImage',
  idBackImage: 'idBackImage',
  businessNtn: 'businessNtn',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.MerchantUserScalarFieldEnum = {
  id: 'id',
  merchantId: 'merchantId',
  email: 'email',
  name: 'name',
  passwordHash: 'passwordHash',
  twoFactorSecret: 'twoFactorSecret',
  isActive: 'isActive',
  lastLoginAt: 'lastLoginAt',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ApiKeyScalarFieldEnum = {
  id: 'id',
  merchantId: 'merchantId',
  keyPrefix: 'keyPrefix',
  keyHash: 'keyHash',
  scopes: 'scopes',
  ipWhitelist: 'ipWhitelist',
  status: 'status',
  lastUsedAt: 'lastUsedAt',
  createdAt: 'createdAt',
  revokedAt: 'revokedAt'
};

exports.Prisma.SupplierScalarFieldEnum = {
  id: 'id',
  name: 'name',
  contactInfo: 'contactInfo',
  status: 'status',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.BrandScalarFieldEnum = {
  id: 'id',
  name: 'name',
  slug: 'slug',
  description: 'description',
  image: 'image',
  sortOrder: 'sortOrder',
  active: 'active',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.CategoryScalarFieldEnum = {
  id: 'id',
  name: 'name',
  slug: 'slug',
  description: 'description',
  image: 'image',
  brandId: 'brandId',
  sortOrder: 'sortOrder',
  active: 'active',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.RegionScalarFieldEnum = {
  id: 'id',
  name: 'name',
  code: 'code',
  currency: 'currency',
  symbol: 'symbol',
  active: 'active',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ProductRegionScalarFieldEnum = {
  id: 'id',
  productId: 'productId',
  regionId: 'regionId',
  active: 'active',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.VariantScalarFieldEnum = {
  id: 'id',
  productRegionId: 'productRegionId',
  name: 'name',
  slug: 'slug',
  description: 'description',
  customerPrice: 'customerPrice',
  currency: 'currency',
  active: 'active',
  sortOrder: 'sortOrder',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.FulfillmentCombinationScalarFieldEnum = {
  id: 'id',
  variantId: 'variantId',
  name: 'name',
  priority: 'priority',
  active: 'active',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.FulfillmentCombinationItemScalarFieldEnum = {
  id: 'id',
  combinationId: 'combinationId',
  denominationId: 'denominationId',
  quantity: 'quantity',
  createdAt: 'createdAt'
};

exports.Prisma.ProductScalarFieldEnum = {
  id: 'id',
  name: 'name',
  region: 'region',
  productType: 'productType',
  categoryId: 'categoryId',
  supplierId: 'supplierId',
  merchantId: 'merchantId',
  status: 'status',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.EssentialsDeliveryItemScalarFieldEnum = {
  id: 'id',
  productId: 'productId',
  denominationId: 'denominationId',
  quantity: 'quantity',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.DenominationScalarFieldEnum = {
  id: 'id',
  productId: 'productId',
  faceValue: 'faceValue',
  currency: 'currency',
  createdAt: 'createdAt'
};

exports.Prisma.CodeItemScalarFieldEnum = {
  id: 'id',
  denominationId: 'denominationId',
  encryptedCode: 'encryptedCode',
  codeHash: 'codeHash',
  status: 'status',
  batchId: 'batchId',
  supplierId: 'supplierId',
  merchantId: 'merchantId',
  source: 'source',
  reservedUntil: 'reservedUntil',
  reservedByReqId: 'reservedByReqId',
  revealedAt: 'revealedAt',
  revealedIp: 'revealedIp',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.FulfillmentRequestScalarFieldEnum = {
  id: 'id',
  merchantId: 'merchantId',
  productId: 'productId',
  amount: 'amount',
  currency: 'currency',
  idempotencyKey: 'idempotencyKey',
  referenceId: 'referenceId',
  status: 'status',
  failureReason: 'failureReason',
  sandbox: 'sandbox',
  customerEmail: 'customerEmail',
  customerName: 'customerName',
  customerAddress: 'customerAddress',
  inventorySource: 'inventorySource',
  walletCharged: 'walletCharged',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.AllocationScalarFieldEnum = {
  id: 'id',
  fulfillmentId: 'fulfillmentId',
  codeItemIds: 'codeItemIds',
  status: 'status',
  createdAt: 'createdAt'
};

exports.Prisma.DeliveryTokenScalarFieldEnum = {
  id: 'id',
  fulfillmentId: 'fulfillmentId',
  tokenHash: 'tokenHash',
  revealedAt: 'revealedAt',
  revealedIp: 'revealedIp',
  createdAt: 'createdAt'
};

exports.Prisma.WalletTransactionScalarFieldEnum = {
  id: 'id',
  merchantId: 'merchantId',
  type: 'type',
  amount: 'amount',
  balanceAfter: 'balanceAfter',
  referenceId: 'referenceId',
  fulfillmentId: 'fulfillmentId',
  createdAt: 'createdAt'
};

exports.Prisma.WebhookEndpointScalarFieldEnum = {
  id: 'id',
  merchantId: 'merchantId',
  url: 'url',
  secret: 'secret',
  status: 'status',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.AuditLogScalarFieldEnum = {
  id: 'id',
  actorType: 'actorType',
  actorId: 'actorId',
  action: 'action',
  entity: 'entity',
  entityId: 'entityId',
  metadata: 'metadata',
  ip: 'ip',
  prevHash: 'prevHash',
  entryHash: 'entryHash',
  createdAt: 'createdAt'
};

exports.Prisma.IdempotencyRecordScalarFieldEnum = {
  id: 'id',
  key: 'key',
  merchantId: 'merchantId',
  requestBodyHash: 'requestBodyHash',
  responseStatus: 'responseStatus',
  responseBody: 'responseBody',
  createdAt: 'createdAt',
  expiresAt: 'expiresAt'
};

exports.Prisma.CustomerScalarFieldEnum = {
  id: 'id',
  email: 'email',
  name: 'name',
  passwordHash: 'passwordHash',
  isActive: 'isActive',
  merchantId: 'merchantId',
  merchantAppStatus: 'merchantAppStatus',
  lastLoginAt: 'lastLoginAt',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.MerchantApplicationScalarFieldEnum = {
  id: 'id',
  customerId: 'customerId',
  storeName: 'storeName',
  storeEmail: 'storeEmail',
  currency: 'currency',
  firstName: 'firstName',
  lastName: 'lastName',
  phone: 'phone',
  idDocType: 'idDocType',
  idFrontImage: 'idFrontImage',
  idBackImage: 'idBackImage',
  businessNtn: 'businessNtn',
  status: 'status',
  adminNote: 'adminNote',
  reviewedBy: 'reviewedBy',
  reviewedAt: 'reviewedAt',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.VerificationCodeScalarFieldEnum = {
  id: 'id',
  customerId: 'customerId',
  code: 'code',
  expiresAt: 'expiresAt',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.EmailLogScalarFieldEnum = {
  id: 'id',
  merchantId: 'merchantId',
  recipient: 'recipient',
  subject: 'subject',
  template: 'template',
  status: 'status',
  providerResponse: 'providerResponse',
  errorMessage: 'errorMessage',
  retryCount: 'retryCount',
  sentAt: 'sentAt',
  createdAt: 'createdAt'
};

exports.Prisma.IncomingWebhookScalarFieldEnum = {
  id: 'id',
  eventId: 'eventId',
  merchantId: 'merchantId',
  platform: 'platform',
  provider: 'provider',
  orderId: 'orderId',
  productId: 'productId',
  productName: 'productName',
  productSku: 'productSku',
  productCategory: 'productCategory',
  customerName: 'customerName',
  customerEmail: 'customerEmail',
  quantity: 'quantity',
  amount: 'amount',
  currency: 'currency',
  paymentStatus: 'paymentStatus',
  orderStatus: 'orderStatus',
  processingStatus: 'processingStatus',
  rawPayload: 'rawPayload',
  rawHeaders: 'rawHeaders',
  signature: 'signature',
  sourceIp: 'sourceIp',
  responseCode: 'responseCode',
  retryCount: 'retryCount',
  errorMessage: 'errorMessage',
  processedAt: 'processedAt',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.AdminWalletScalarFieldEnum = {
  id: 'id',
  balance: 'balance',
  currency: 'currency',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.AdminWalletTransactionScalarFieldEnum = {
  id: 'id',
  adminWalletId: 'adminWalletId',
  type: 'type',
  amount: 'amount',
  balanceAfter: 'balanceAfter',
  referenceId: 'referenceId',
  source: 'source',
  description: 'description',
  createdAt: 'createdAt'
};

exports.Prisma.FundingRequestScalarFieldEnum = {
  id: 'id',
  merchantId: 'merchantId',
  adminWalletId: 'adminWalletId',
  amount: 'amount',
  currency: 'currency',
  note: 'note',
  screenshot: 'screenshot',
  status: 'status',
  adminNote: 'adminNote',
  reviewedBy: 'reviewedBy',
  reviewedAt: 'reviewedAt',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.SupportMessageScalarFieldEnum = {
  id: 'id',
  merchantId: 'merchantId',
  senderRole: 'senderRole',
  senderName: 'senderName',
  body: 'body',
  image: 'image',
  fundingRequestId: 'fundingRequestId',
  readByAdmin: 'readByAdmin',
  readByMerchant: 'readByMerchant',
  createdAt: 'createdAt'
};

exports.Prisma.PlatformSettingScalarFieldEnum = {
  key: 'key',
  value: 'value',
  updatedAt: 'updatedAt'
};

exports.Prisma.CodeBatchScalarFieldEnum = {
  id: 'id',
  denominationId: 'denominationId',
  quantity: 'quantity',
  supplierId: 'supplierId',
  costPerCode: 'costPerCode',
  currency: 'currency',
  note: 'note',
  createdBy: 'createdBy',
  createdAt: 'createdAt'
};

exports.Prisma.ConnectedProductScalarFieldEnum = {
  id: 'id',
  merchantId: 'merchantId',
  platform: 'platform',
  provider: 'provider',
  platformProductId: 'platformProductId',
  platformSku: 'platformSku',
  name: 'name',
  sku: 'sku',
  category: 'category',
  imageUrl: 'imageUrl',
  price: 'price',
  currency: 'currency',
  stock: 'stock',
  status: 'status',
  inventorySource: 'inventorySource',
  dcvProductId: 'dcvProductId',
  dcvDenominationId: 'dcvDenominationId',
  dcvVariantId: 'dcvVariantId',
  lastSyncedAt: 'lastSyncedAt',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.PaymentRecordScalarFieldEnum = {
  id: 'id',
  customerId: 'customerId',
  merchantId: 'merchantId',
  customerOrderId: 'customerOrderId',
  stripeCheckoutSessionId: 'stripeCheckoutSessionId',
  stripePaymentIntentId: 'stripePaymentIntentId',
  stripeEventId: 'stripeEventId',
  amount: 'amount',
  currency: 'currency',
  status: 'status',
  paymentType: 'paymentType',
  description: 'description',
  metadata: 'metadata',
  refundAmount: 'refundAmount',
  refundReason: 'refundReason',
  refundedAt: 'refundedAt',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  paidAt: 'paidAt'
};

exports.Prisma.CustomerOrderScalarFieldEnum = {
  id: 'id',
  customerId: 'customerId',
  customerEmail: 'customerEmail',
  customerName: 'customerName',
  productId: 'productId',
  denominationId: 'denominationId',
  amount: 'amount',
  currency: 'currency',
  status: 'status',
  fulfillmentId: 'fulfillmentId',
  revealToken: 'revealToken',
  errorMessage: 'errorMessage',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.SortOrder = {
  asc: 'asc',
  desc: 'desc'
};

exports.Prisma.QueryMode = {
  default: 'default',
  insensitive: 'insensitive'
};

exports.Prisma.NullsOrder = {
  first: 'first',
  last: 'last'
};


exports.Prisma.ModelName = {
  AdminUser: 'AdminUser',
  Merchant: 'Merchant',
  MerchantUser: 'MerchantUser',
  ApiKey: 'ApiKey',
  Supplier: 'Supplier',
  Brand: 'Brand',
  Category: 'Category',
  Region: 'Region',
  ProductRegion: 'ProductRegion',
  Variant: 'Variant',
  FulfillmentCombination: 'FulfillmentCombination',
  FulfillmentCombinationItem: 'FulfillmentCombinationItem',
  Product: 'Product',
  EssentialsDeliveryItem: 'EssentialsDeliveryItem',
  Denomination: 'Denomination',
  CodeItem: 'CodeItem',
  FulfillmentRequest: 'FulfillmentRequest',
  Allocation: 'Allocation',
  DeliveryToken: 'DeliveryToken',
  WalletTransaction: 'WalletTransaction',
  WebhookEndpoint: 'WebhookEndpoint',
  AuditLog: 'AuditLog',
  IdempotencyRecord: 'IdempotencyRecord',
  Customer: 'Customer',
  MerchantApplication: 'MerchantApplication',
  VerificationCode: 'VerificationCode',
  EmailLog: 'EmailLog',
  IncomingWebhook: 'IncomingWebhook',
  AdminWallet: 'AdminWallet',
  AdminWalletTransaction: 'AdminWalletTransaction',
  FundingRequest: 'FundingRequest',
  SupportMessage: 'SupportMessage',
  PlatformSetting: 'PlatformSetting',
  CodeBatch: 'CodeBatch',
  ConnectedProduct: 'ConnectedProduct',
  PaymentRecord: 'PaymentRecord',
  CustomerOrder: 'CustomerOrder'
};

/**
 * This is a stub Prisma Client that will error at runtime if called.
 */
class PrismaClient {
  constructor() {
    return new Proxy(this, {
      get(target, prop) {
        let message
        const runtime = getRuntime()
        if (runtime.isEdge) {
          message = `PrismaClient is not configured to run in ${runtime.prettyName}. In order to run Prisma Client on edge runtime, either:
- Use Prisma Accelerate: https://pris.ly/d/accelerate
- Use Driver Adapters: https://pris.ly/d/driver-adapters
`;
        } else {
          message = 'PrismaClient is unable to run in this browser environment, or has been bundled for the browser (running in `' + runtime.prettyName + '`).'
        }
        
        message += `
If this is unexpected, please open an issue: https://pris.ly/prisma-prisma-bug-report`

        throw new Error(message)
      }
    })
  }
}

exports.PrismaClient = PrismaClient

Object.assign(exports, Prisma)
